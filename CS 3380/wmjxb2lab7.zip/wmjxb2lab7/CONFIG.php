<?php

$USERNAME="wmjxb2";
$HOSTNAME="localhost";
$PASSWORD="a45806625?";
$DATABASE="wmjxb2";

?>
